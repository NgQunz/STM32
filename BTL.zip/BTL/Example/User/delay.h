#ifndef _DELAY_H_
#define _DELAY_H_

#include "stm32f10x.h"

// Khai b�o h�m delay
void delay_us(uint32_t us);
void delay_ms(uint32_t time);

#endif

