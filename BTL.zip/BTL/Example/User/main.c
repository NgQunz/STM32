#include "stm32f10x.h"
#include "Delay.h"
#include "LCD.h"
#include "MQ2.h"
#include "Speaker.h"

// Cau hinh dong ho he thong
void SystemClock_Config(void) {
    RCC_HSEConfig(RCC_HSE_ON);
    while (!RCC_GetFlagStatus(RCC_FLAG_HSERDY));
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);
    RCC_PLLCmd(ENABLE);
    while (!RCC_GetFlagStatus(RCC_FLAG_PLLRDY));
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
    RCC_HCLKConfig(RCC_SYSCLK_Div1);  // AHB = 72 MHz
    RCC_PCLK1Config(RCC_HCLK_Div2);   // APB1 = 36 MHz
    RCC_PCLK2Config(RCC_HCLK_Div1);   // APB2 = 72 MHz
}

int main(void) {
    SystemClock_Config(); // Khoi tao dong ho he thong
    I2C_Init_Custom();    // Khoi tao I2C
    LCD_Init();           // Khoi tao LCD
    MQ2_Init();           // Khoi tao cam bien MQ2 (ADC)
    Speaker_Init();       // Khoi tao coi

    // Hien thi thong diep khoi dong
    LCD_Print("Canh bao khi gas ");
    delay_ms(2000);
    LCD_SendCommand(0x01); // Xoa man hinh
    delay_ms(2);

    while (1) {
        // Doc nong do khi
        uint32_t ppm = MQ2_Read_ppm();

        // Hien thi nong do ppm
        LCD_SendCommand(0x80); // Di chuyen den dong 1
        LCD_Print("Gas: ");
        LCD_PrintNumber(ppm);
        LCD_Print(" ppm    "); // Xoa ky tu du

        // Kiem tra nguong
        if (ppm > 200) {
            LCD_SendCommand(0xC0); // Dong 2
            LCD_Print("Nguy hiem");
            Speaker_On(); // Bat coi
        } else if (ppm > 100) {
            LCD_SendCommand(0xC0); // Dong 2
            LCD_Print("Bao dong ");
            Speaker_Off(); // Tat coi
        } else {
            LCD_SendCommand(0xC0); // Dong 2
            LCD_Print("An toan ");
            Speaker_Off(); // Tat coi
        }

        delay_ms(500); // Cap nhat moi 500ms
    }
}
