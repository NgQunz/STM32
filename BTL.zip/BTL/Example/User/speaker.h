#ifndef _SPEAKER_H_
#define _SPEAKER_H_

#include "stm32f10x.h"

// Khai b�o h�m c�i b�o dong
void Speaker_Init(void);
void Speaker_On(void);
void Speaker_Off(void);

#endif

