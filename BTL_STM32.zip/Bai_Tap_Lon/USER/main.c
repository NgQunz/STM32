#include "sys.h"

int main(void)
{
    System_Init();
    while (1)
    {
    //System_Run();
    }
}


